"""
pyoccam – Python bindings + helpers for OCCAM (variable-based RA)

Flat package layout:
    pyoccam/
      ├─ __init__.py          (this file)
      ├─ pyoccam_pybind11.cpp (C++ bindings built as extension)
      ├─ pyoccam_demo.py
      ├─ pyoccam_demo.ipynb
      ├─ dementia05.txt
      └─ landslides.txt
"""

# ---------- version ----------
try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("pyoccam")
except Exception:
    __version__ = "0.0.0"

# ---------- load C++ extension (support two common names) ----------
# Prefer the "_core" module name (recommended), but fall back to "pyoccam" if your build uses that.
_PYBIND_ERR = None
try:
    from ._core import PyVBMManager, PyModel     # recommended extension name
except Exception as e1:
    try:
        from .pyoccam import PyVBMManager, PyModel  # fallback name
    except Exception as e2:
        _PYBIND_ERR = (e1, e2)
        PyVBMManager = None
        PyModel = None

# Back-compat alias so old notebooks using VBMManager keep working
VBMManager = PyVBMManager

# ---------- resource helpers (flat files live directly under pyoccam/) ----------
try:
    from importlib.resources import files as _files  # py3.9+
except Exception:  # pragma: no cover
    from importlib_resources import files as _files  # backport if ever needed

def _pkg_path(name: str) -> str:
    """Absolute path to a packaged file in the flat pyoccam/ directory."""
    return str(_files(__name__).joinpath(name))

def data_path(name: str) -> str:
    """Alias for packaged data path (e.g., 'dementia05.txt', 'landslides.txt')."""
    return _pkg_path(name)

def demo_path() -> str:
    """Absolute path to 'pyoccam_demo.py'."""
    return _pkg_path("pyoccam_demo.py")

def notebook_path() -> str:
    """Absolute path to 'pyoccam_demo.ipynb'."""
    return _pkg_path("pyoccam_demo.ipynb")

# ---------- convenient demo runner ----------
def run_demo(dataset: str = "dementia05.txt",
             search_type: str = "loopless",
             levels: int = 7,
             width: int = 3,
             start: str = "bottom",
             direction: str = "up",
             ref: str = "b

#!/usr/bin/env python3
"""
Demo: OCCAM Fit Report Analyzer
Shows how to use the analyzer programmatically
"""

from analyze_fit import FitReportAnalyzer
import json

# Example 1: Load and analyze a fit report
print("=" * 80)
print("EXAMPLE 1: Basic Analysis")
print("=" * 80)

with open('/mnt/project/dementia05_fit_IV_ApZ_EdZ_CZ.csv', 'r') as f:
    report = f.read()

analyzer = FitReportAnalyzer(report)
analyzer.print_summary()


# Example 2: Access findings programmatically
print("\n\n" + "=" * 80)
print("EXAMPLE 2: Programmatic Access")
print("=" * 80)

findings = analyzer.analyze()

print("\n📊 Overview:")
for key, value in findings['overview'].items():
    print(f"  - {key}: {value}")

print("\n📈 Model Quality:")
for key, value in findings['model_quality'].items():
    print(f"  - {key}: {value}")

print(f"\n🎯 Found {len(findings['conditional_patterns'])} conditional DV patterns")
print(f"🎲 Analyzed {len(findings['confusion_insights'])} confusion matrices")
print(f"💡 Generated {len(findings['recommendations'])} recommendations")


# Example 3: Export to JSON for further processing
print("\n\n" + "=" * 80)
print("EXAMPLE 3: JSON Export")
print("=" * 80)

# Convert to JSON-serializable format
json_data = {
    'overview': findings['overview'],
    'model_quality': findings['model_quality'],
    'num_patterns': len(findings['conditional_patterns']),
    'num_confusion_matrices': len(findings['confusion_insights']),
    'recommendations': findings['recommendations']
}

print(json.dumps(json_data, indent=2))


# Example 4: Focus on specific insights
print("\n\n" + "=" * 80)
print("EXAMPLE 4: Custom Analysis - Low Accuracy States")
print("=" * 80)

for pattern in findings['conditional_patterns']:
    if pattern['type'] == 'low_accuracy':
        print(f"\n⚠️ {pattern['relation']}:")
        print(f"  {pattern['details']}")
        for ex in pattern.get('examples', []):
            print(f"    • {ex}")


# Example 5: Confusion Matrix Comparison
print("\n\n" + "=" * 80)
print("EXAMPLE 5: Confusion Matrix Ranking")
print("=" * 80)

# Sort by F1 score
cm_by_f1 = sorted(findings['confusion_insights'], 
                  key=lambda x: x.get('Strongest', '').split('=')[1] if 'F1' in x.get('Strongest', '') else 0,
                  reverse=True)

print("\nTop performing confusion matrices by their strongest metric:\n")
for i, cm in enumerate(findings['confusion_insights'][:3], 1):
    print(f"{i}. {cm['relation']}")
    print(f"   Accuracy: {cm['accuracy']}")
    print(f"   {cm['best']}")
    print(f"   {cm['worst']}")
    print()

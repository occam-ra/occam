# pyoccam package
from .pyoccam import *
import os
from pathlib import Path

__version__ = '0.1.0'

# Get the package directory
PACKAGE_DIR = Path(__file__).parent

# Helper functions for accessing packaged data
def get_data_file(filename):
    """Get the full path to a packaged data file"""
    path = PACKAGE_DIR / filename
    if path.exists():
        return str(path)
    else:
        raise FileNotFoundError(f"Data file '{filename}' not found in package")

def get_demo_file(filename):
    """Get the full path to a packaged demo file"""
    path = PACKAGE_DIR / filename
    if path.exists():
        return str(path)
    else:
        raise FileNotFoundError(f"Demo file '{filename}' not found in package")

def list_data_files():
    """List all available data files"""
    return [f.name for f in PACKAGE_DIR.glob("*.txt") if f.is_file()]

def list_demo_files():
    """List all available demo files"""
    demos = list(PACKAGE_DIR.glob("pyoccam_demo.*"))
    return [f.name for f in demos if f.is_file()]

# Convenience paths for common data files (if they exist)
try:
    DEMENTIA_DATA = get_data_file("dementia05.txt")
except FileNotFoundError:
    DEMENTIA_DATA = None

try:
    DEMENTIA_APEDC_DATA = get_data_file("dementia05ApEdC.txt")
except FileNotFoundError:
    DEMENTIA_APEDC_DATA = None

try:
    LANDSLIDES_DATA = get_data_file("landslides.txt")  
except FileNotFoundError:
    LANDSLIDES_DATA = None

try:
    SY_SAMPLE_DATA = get_data_file("SY_sample_pts_to_occam3_shuffle_split42_hdr.txt")
except FileNotFoundError:
    SY_SAMPLE_DATA = None

# Quick demo runner
def run_demo(data_file=None):
    """Run the pyoccam demo with optional data file
    
    Args:
        data_file: Path to data file, or None to use default
    
    Example:
        import pyoccam
        pyoccam.run_demo()  # Use default data
        pyoccam.run_demo(pyoccam.LANDSLIDES_DATA)  # Use landslides data
    """
    import subprocess
    import sys
    
    try:
        demo_path = get_demo_file("pyoccam_demo.py")
    except FileNotFoundError:
        print("Demo file not found in package. Please ensure pyoccam_demo.py is included.")
        return
    
    if data_file:
        # Modify the demo to use specified data file
        import tempfile
        with open(demo_path, 'r') as f:
            demo_code = f.read()
        
        # Replace the DATA_FILE line
        demo_code = demo_code.replace(
            'DATA_FILE = "dementia05.txt"',
            f'DATA_FILE = "{data_file}"'
        )
        
        # Run modified demo
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as tmp:
            tmp.write(demo_code)
            tmp_path = tmp.name
        
        try:
            subprocess.run([sys.executable, tmp_path])
        finally:
            os.unlink(tmp_path)
    else:
        subprocess.run([sys.executable, demo_path])

# Print package info when imported interactively
if __name__ != "__main__":
    import sys
    if hasattr(sys, 'ps1'):  # Interactive mode
        print(f"pyoccam {__version__} loaded")
        if list_data_files():
            print(f"Available data files: {', '.join(list_data_files())}")
        if list_demo_files():
            print(f"Available demos: {', '.join(list_demo_files())}")
        print("Run pyoccam.run_demo() to see a demonstration")

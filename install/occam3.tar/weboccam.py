#! /usr/local/bin/python
import os, cgi, sys, occam, string
from ocutils import ocUtils

#
#---- getDataFileName -- get the original name of the data file
#
def getDataFileName(form):
	# extract the file name (minus directory) and seed the download dialog with it
	# we have to handle both forward and backward slashes here.
	datafile = "occamdata"
	if form.has_key("datafile"):
		datafile = form["datafile"].value
		if string.find(datafile, "\\") >= 0:
			datapath = string.split(datafile, "\\");
		else:
			datapath = string.split(datafile, "/");
		datafile = os.path.splitext(datapath[len(datapath)-1])[0]
	return datafile

#
#---- printHeaders ---- Print HTTP Headers
#
def printHeaders(form, textFormat):
	datafile = getDataFileName(form)
	datafile = datafile + ".csv"
	if textFormat:
#		print "Content-type: application/vnd.ms-excel"
#		print "Content-location: " + datafile
		print "Content-type: application/octet-stream"
		print "Content-disposition: attachment; filename=" + datafile
	else:
		print "Content-type: text/html"
	print ""

#
#---- printTop ---- Print top HTML part
#
def printTop():
	print """
	<html>
	<head>
		<link REL="stylesheet" HREF="base.css" TYPE="text/css"></link>
		<title>Occam3 Test Drive</title>
	</head>
	<body>
	<img src="occam_logo.jpg">
	"""
#
#---- printBottom ---- Print bottom HTML part
#
def printBottom():
	print """
	</body>
	</html>
	"""

#
#---- printRadio ---- print a radio button set
#
def printRadio(label, name, values, form, default):
	print "<TR  class=form>"
	print "<TD>%s</TD><TD>" % label
	states = {}
	states[default] = "checked"
	for value in values:
		if form.has_key(name) and value[0] == form[name].value :
			states[default] = ""
			states[value[0]] = "checked"

	for value in values:
		print "&nbsp;&nbsp;&nbsp;<INPUT type=radio %s NAME=%s VALUE=%s>%s" %(states.get(value[0], ""), name, value[0], value[1])
	print "</TD></TR>"

#
# ---- printRadioRefresh ---- print a radio button set which refreshes the page
#
def printButtonsRefresh(name, values, form):
	print "<TR class=form>"
	for value in values:
		checked = ""
		if form.has_key(name) and value[0] == form[name].value : checked = "checked" 
		print "<TD><INPUT type=radio %s NAME=%s VALUE=%s onClick='parent.location=\"weboccam.py?%s=%s\";'>%s</TD>" %(checked, name, value[0], name, value[0], value[1])
	print "</TR>"

#
#---- printSearchOptions ---- display the search options part of the form
#
def printSearchOptions(model, datafile, sortLevels, specificRefModel):
	print """
	<TR class=form>
		<TD>Data File:</TD>
		<TD colspan=4><INPUT TYPE="file" NAME="data">
		</TD>
	</TR>

	<TR class=form>
		<TD>Starting Model:</TD>
		<TD><INPUT NAME="model" VALUE="%s"></TD>
	</TR>
	""" % model

	printRadio("Reference Model:", "refmodel", 
		(("default", "Default"),
		("top", "Top"),
		("bottom", "Bottom"),
		("starting", "Starting Model")
		),
		form, "default")

	print "<tr><td colspan=99><hr></td></tr>"

	printRadio("Models to Consider:", "searchtype",
	 	(("all", "All"),
 		("loopless", "Loopless"),
		("disjoint", "Disjoint"),
		("chain", "Chain")
		), form, "all")
	printRadio("Search Direction:", "searchdir", (("default", "Default"), ("up", "Up"), ("down", "Down")), form, "default")
	printRadio("During Search, Sort By:", "sortby",
		(("information", "Information"),
		("alpha", "Alpha")), form, "information")
	printRadio("When Searching, Prefer:", "searchsortdir",
		(("descending", "Larger Values"),
		("ascending", "Smaller Values")),
		form, "descending")

	print "<tr><td colspan=99><hr></td></tr>"

	printRadio("In Report, Sort By:", "sortreportby",
		(("information", "Information"),
		("alpha", "Alpha"), 
		("ddf", "dDF"),
		("levels", "Level")),
		form, "information")

	printRadio("In Report, Sort:", "sortdir",
		(("descending", "Descending"),
		("ascending", "Ascending")),
		form, "descending")


#
#---- printFitOptions ---- print the options for fit	
#
def printFitOptions(model, datafile, specificRefModel):
	print """
	<TR class=form>
		<TD>Model to Fit:</TD>
		<TD><INPUT NAME="model" VALUE="%s"></TD>
	</TR>
	<TR class=form>
		<TD>Data File:</TD>
		<TD colspan=2>
			<INPUT TYPE="file" NAME="data">
		</TD>
	</TR>
	""" % model

	printRadio("Reference Model:", "refmodel", 
		(("default", "Default"),
		("top", "Top"),
		("bottom", "Bottom"),
		("starting", "Starting Model"),
		),
		form, "default")


#
#---- printForm ---- Print the data input form
#
def printForm(form):
	datafile = ""
	if form.has_key("datafile"): datafile = form["datafile"].value

	model = ""
	if form.has_key("model"): model = form["model"].value

	action = ""
	if form.has_key("action"): action = form["action"].value

	sortLevels = ""
	if form.has_key("sort_levels"): sortLevels = "checked"

	printOptions = ""
	if form.has_key("printoptions"): printOptions = "checked"

	formatText = ""
	if form.has_key("formatText"): formatText = "checked"

	specificRefModel = ""
	if form.has_key("specificRefModel"): specificRefModel = form["specificrefmodel"].value

	print """
	<form METHOD=POST TARGET="results" action="/occam/weboccam.py" enctype=multipart/form-data>
	<table class=form>
	"""
	printButtonsRefresh("action", (("fit", "Do Fit"), ("search", "Do Search")), form)

	#---- This form section for fit only
	if action == "fit":
		printFitOptions(model, datafile, specificRefModel)

	#---- This section for search only
	elif action == "search":
		printSearchOptions(model, datafile, sortLevels, specificRefModel)

	if action != "":
		print "<TR><TD colspan=2><INPUT type=checkbox NAME='format' %s VALUE='text'>Return data in spreadsheet format</TD></TR>" % formatText
		print "<TR><TD colspan=2><INPUT type=checkbox NAME='printoptions' checked VALUE='true'>Print option settings</TD></TR>"
	print "</TABLE>"
	if action != "":
		print"<INPUT TYPE=SUBMIT VALUE=Send>"

	print "</FORM>"


#
#---- actionForm ---- put up the input form
#
def actionForm(form, errorText):
	if errorText:
		print "<H2>Error: %s</H2><BR>" % errorText
	printForm(form)

#
#---- getDataFile ---- get the posted data and store to temp file
#
def getDataFile(form):
	global datafile
	datafile = "/tmp/" + getDataFileName(form)
	try:
		outf = open(datafile, "w")
		data = form["data"].value
		outf.write(data)
		outf.close()
	except:
		print "Error: problems reading data file %s" % datafile
	return datafile

#
#---- processFit ---- Do fit operation
#
def processFit(fn, model, oc):
	global datafile, textFormat, printOptions
	oc.setDataFile(form["data"].filename)


	if textFormat:
		oc.setReportSeparator(ocUtils.COMMASEP)
	else:
		oc.setReportSeparator(ocUtils.HTMLFORMAT)

	if model <> "":
		oc.setFitModel(model)
	oc.setAction("fit")
	oc.doAction(printOptions)

#
#---- actionFit ---- Report on Fit
#
def actionFit(form):
	global textFormat

	fn = getDataFile(form)
	oc = ocUtils()
	oc.initFromCommandLine(["",fn])

	if not form.has_key("data") or not form.has_key("model") :
		actionNone(form, "Missing form fields")
		return
	model = form["model"].value

	if textFormat:
		processFit(fn, model)
	else:
		print "<span class=mono>"
		processFit(fn, model, oc)
		print "</span>"

#
#---- processSearch ---- Do search operation
#
def processSearch(fn, oc):
	global sortName, sortReportName, searchDir, refModel, sortDir, searchSortDir, startModel
	global searchType, sortDir, sortLevels
	global datafile, textFormat, printOptions
	oc.setDataFile(form["data"].filename)

	if textFormat:
		oc.setReportSeparator(ocUtils.COMMASEP)
	else:
		oc.setReportSeparator(ocUtils.HTMLFORMAT)

	if sortDir <> "":
		oc.setSortDir(sortDir)

	oc.setReportSortName(sortReportName)

	oc.setStartModel(startModel)
	oc.setRefModel(refModel)
	oc.setSearchDir(searchDir)
	oc.setSearchSortDir(searchSortDir)
	oc.setSearchFilter(searchType)
	oc.setAction("search")
	oc.setSortName(sortName)
	if textFormat:
		oc.doAction(printOptions)
	else:
		print "<table>"
		print "</table><hr><p>"
		print "<div class=data>"
		oc.doAction(printOptions)
		print "</div>"

#
#---- actionSearch ---- Search the lattice of models
def actionSearch(form):
	global sortName, sortReportName, searchDir, searchType, sortDir, searchSortDir
	global sortLevels, refModel, specificRefModel, startModel

	fn = getDataFile(form)
	oc = ocUtils()
	oc.initFromCommandLine(["",fn])

	if not form.has_key("data") :
		actionForm(form, "Missing form fields")
		return
	startModel = "default"
	if form.has_key("model") :
		startModel = form["model"].value

	if form.has_key("searchdir") :
		searchDir = form["searchdir"].value
	else:
		searchDir = "default"

	if form.has_key("sortby") :
		sortName = form["sortby"].value
	else:
		sortName = ""

	if form.has_key("sortreportby") :
		sortReportName = form["sortreportby"].value
	else:
		sortReportName = ""

	if form.has_key("searchtype") :
		searchType = form["searchtype"].value
	else:
		searchType = "all"
	
	sortDir = ""
	if form.has_key("sortdir"):
		sortDir = form["sortdir"].value

	searchSortDir = ""
	if form.has_key("searchsortdir"):
		searchSortDir = form["searchsortdir"].value

	sortLevels = ""
	if form.has_key("sort_levels"):
		sortLevels = form["sort_levels"].value

	if startModel <> "":
		oc.setStartModel(startModel)

	refModel = "default"
	if form.has_key("refmodel"):
		if form["refmodel"].value == "specific" and form.has_key("specificrefmodel"):
			refModel = form["specificrefmodel"].value
			specificRefModel = refModel
		elif form["refmodel"].value == "starting":
			refModel = oc.getStartModel()
		else:
			refModel = form["refmodel"].value

	processSearch(fn, oc)

#
#---- actionError ---- print error on unknown action
#
def actionError():
	print "<H1>Error: unknown action</H1>"

#
#---- main script ----
#
datafile = ""
textFormat = ""
printOptions = ""
form = cgi.FieldStorage()

if form.has_key("format") and form["format"].value == "text":
	textFormat = "true"

if form.has_key("printoptions"):
	printOptions = "true"

printHeaders(form, textFormat)

if not textFormat:
	printTop()

if not form.has_key("data"):
	actionForm(form, None)

if form.has_key("action") and form.has_key("data"):
	if form["action"].value == "fit" :
		actionFit(form)
	elif form["action"].value == "search" :
		actionSearch(form)
	else:
		actionError()

if not textFormat:
	printBottom()


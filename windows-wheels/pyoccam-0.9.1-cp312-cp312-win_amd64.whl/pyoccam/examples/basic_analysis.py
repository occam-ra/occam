#!/usr/bin/env python3
"""
PyOccam Basic Analysis Script
=============================
Simple workflow for OCCAM Reconstructability Analysis.

Workflow:
1. Load data
2. Run search
3. Select best model (BIC, AIC, or Information)
4. Fit selected model
5. Generate reports
"""

import pyoccam
import os
from datetime import datetime

# =============================================================================
# CONFIGURATION - Modify these settings for your analysis
# =============================================================================

# Data Selection
DATASET = "dementia"              # Options: "dementia", "landslides", or path to your file

# Search Configuration
SEARCH_TYPE = "loopless-up"       # Options: "loopless-up", "full-up", "disjoint-up", "chain-up"
SEARCH_LEVELS = 7                 # Depth to search (1-10, typically 5-7)
SEARCH_WIDTH = 3                  # Models to keep per level (1-10, typically 3-5)

# Model Selection Method
MODEL_SELECTION = "BIC"           # Options: "BIC", "AIC", "INFO"

# Output Configuration
OUTPUT_FORMAT = "space"           # Options: "space", "tab", "comma"
SAVE_REPORTS = True               # Save reports to files?

# Advanced Options
TARGET_STATE = "0"                # For confusion matrix (DV negative state)
SHOW_CONFUSION_MATRIX = True      # Display confusion matrix for fitted model?

# =============================================================================
# Analysis Execution (Do not modify below this line)
# =============================================================================

print("=" * 70)
print("PYOCCAM BASIC ANALYSIS")
print("=" * 70)
print(f"Configuration:")
print(f"  Dataset: {DATASET}")
print(f"  Search: {SEARCH_TYPE}, levels={SEARCH_LEVELS}, width={SEARCH_WIDTH}")
print(f"  Model Selection: {MODEL_SELECTION}")
print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 70)

# Step 1: Load Data
print("\n[Step 1/5] Loading data...")
print("-" * 40)

if DATASET == "dementia":
    data = pyoccam.load_dementia()
elif DATASET == "landslides":
    data = pyoccam.load_landslides()
elif os.path.exists(DATASET):
    data = pyoccam.load_data(DATASET)
else:
    raise FileNotFoundError(f"Dataset not found: {DATASET}")

print(f"✓ Loaded: {os.path.basename(data.data_file)}")
print(f"  Samples: {data.n_samples}")
print(f"  Features: {data.n_features}")
print(f"  Target: {data.target_name}")

# Get manager
manager = data.manager

# Step 2: Configure Search
print("\n[Step 2/5] Configuring search...")
print("-" * 40)

# Set output format
if OUTPUT_FORMAT == "comma":
    manager.set_report_separator(pyoccam.COMMASEP)
elif OUTPUT_FORMAT == "tab":
    manager.set_report_separator(pyoccam.TABSEP)
else:
    manager.set_report_separator(pyoccam.SPACESEP)

# Configure report variables (don't include ID or Model - added automatically)
manager.set_report_variables("Level$I, h, ddf, dLR, Alpha, %dH(DV), dAIC, dBIC")

print(f"✓ Search configured: {SEARCH_TYPE}")
print(f"  Levels: {SEARCH_LEVELS}, Width: {SEARCH_WIDTH}")

# Step 3: Run Search
print("\n[Step 3/5] Running search...")
print("-" * 40)

search_report = manager.generate_search_report(SEARCH_TYPE, SEARCH_LEVELS, SEARCH_WIDTH)

# Display search results
lines = [l for l in search_report.strip().split('\n') if l.strip()]
model_count = len([l for l in lines if l.strip() and l.strip()[0].isdigit()])

print(f"✓ Search complete: {model_count} models found")
print(f"\nTop models from search:")
print("=" * 80)

# Show header and top 15 models
in_data_section = False
lines_shown = 0
for line in lines:
    # Show header lines
    if 'ID' in line and 'MODEL' in line:
        print(line)
        in_data_section = True
        continue
    if line.startswith('---') or line.startswith('==='):
        if in_data_section and lines_shown > 0:
            break
        print(line)
        continue
    # Show data lines
    if in_data_section and line.strip() and line.strip()[0].isdigit():
        print(line)
        lines_shown += 1
        if lines_shown >= 15:
            break

if model_count > 15:
    print(f"... and {model_count - 15} more models")
print("=" * 80)

# Step 4: Select Best Model
print(f"\n[Step 4/5] Selecting best model by {MODEL_SELECTION}...")
print("-" * 40)

if MODEL_SELECTION.upper() == "BIC":
    best_model = manager.get_best_model_by_bic()
elif MODEL_SELECTION.upper() == "AIC":
    best_model = manager.get_best_model_by_aic()
elif MODEL_SELECTION.upper() == "INFO":
    best_model = manager.get_best_model_by_information()
else:
    raise ValueError(f"Invalid MODEL_SELECTION: {MODEL_SELECTION}. Use BIC, AIC, or INFO")

if not best_model:
    print("✗ No best model found. Check search results.")
    exit(1)

print(f"✓ Selected model: {best_model}")
print(f"  Selection criterion: {MODEL_SELECTION}")

# Step 5: Fit Model and Generate Report
print(f"\n[Step 5/5] Fitting model...")
print("-" * 40)

fit_report = manager.generate_fit_report(best_model)

if fit_report:
    print(f"✓ Model fitted successfully")
    
    # Display key sections from fit report
    print("\nKey Statistics from Fit Report:")
    print("=" * 80)
    
    lines = fit_report.split('\n')
    show_lines = False
    lines_shown = 0
    
    for i, line in enumerate(lines):
        # Show option settings section
        if 'Option settings:' in line or 'State Space Size' in line:
            show_lines = True
        
        # Show lines in key sections
        if show_lines:
            print(line)
            lines_shown += 1
            
            # Stop after showing basic stats (usually first ~30 lines)
            if lines_shown > 30 or (lines_shown > 10 and line.strip() == ''):
                break
    
    print("=" * 80)
    
    # Show confusion matrix if requested
    if SHOW_CONFUSION_MATRIX and hasattr(manager, 'get_confusion_matrix'):
        print(f"\nConfusion Matrix (DV state={TARGET_STATE}):")
        cm = manager.get_confusion_matrix(best_model, TARGET_STATE)
        if cm and isinstance(cm, dict) and "error" not in cm:
            tn = cm.get('tn', 0)
            fp = cm.get('fp', 0)
            fn = cm.get('fn', 0)
            tp = cm.get('tp', 0)
            total = tp + tn + fp + fn
            if total > 0:
                accuracy = (tp + tn) / total
                print(f"  Accuracy: {accuracy:.2%}")
                print(f"  TP: {tp:4.0f}  FN: {fn:4.0f}")
                print(f"  FP: {fp:4.0f}  TN: {tn:4.0f}")
            else:
                print(f"  Warning: No confusion matrix values available")
        else:
            error_msg = cm.get('error', 'Unknown error') if isinstance(cm, dict) else 'No confusion matrix returned'
            print(f"  Note: {error_msg}")
else:
    print("✗ Model fit failed")

# Save Reports
if SAVE_REPORTS:
    print("\n[Saving Reports]")
    print("-" * 40)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Save search report
    search_filename = f"search_{SEARCH_TYPE}_{timestamp}.txt"
    with open(search_filename, 'w') as f:
        f.write(search_report)
    print(f"✓ Search report: {search_filename}")
    
    # Save fit report
    if fit_report:
        fit_filename = f"fit_{best_model.replace(':', '_')}_{timestamp}.txt"
        with open(fit_filename, 'w') as f:
            f.write(fit_report)
        print(f"✓ Fit report: {fit_filename}")

# Summary
print("\n" + "=" * 70)
print("ANALYSIS COMPLETE")
print("=" * 70)
print(f"Dataset: {os.path.basename(data.data_file)}")
print(f"Best Model ({MODEL_SELECTION}): {best_model}")
print(f"Search Type: {SEARCH_TYPE}")
if SAVE_REPORTS:
    print(f"\nReports saved to current directory")
print("=" * 70)

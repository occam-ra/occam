#!/usr/bin/env python3
"""
PyOccam Advanced Analysis Script
================================
Comprehensive workflow with multiple search algorithms and model comparisons.

Features:
- Multiple search algorithm comparison
- Top N model analysis
- Confusion matrix extraction
- Model comparison tables
- Comprehensive reporting
"""

import pyoccam
import os
from datetime import datetime

# =============================================================================
# CONFIGURATION - Modify these settings for your analysis
# =============================================================================

# Data Selection
DATASET = "dementia"              # Options: "dementia", "landslides", or path to your file

# Search Configuration
SEARCH_TYPES = ["loopless-up", "full-up"]  # List of algorithms to compare
SEARCH_LEVELS = 7                 # Depth to search (1-10, typically 5-7)
SEARCH_WIDTH = 3                  # Models to keep per level (1-10, typically 3-5)

# Model Selection and Analysis
MODEL_SELECTION = "BIC"           # Options: "BIC", "AIC", "INFO"
ANALYZE_TOP_N = 3                 # Fit and analyze top N models
COMPARE_ALL_CRITERIA = True       # Show best model for BIC, AIC, and Information?

# Confusion Matrix Settings
EXTRACT_CONFUSION_MATRICES = True # Calculate confusion matrices?
TARGET_STATE = "0"                # DV negative state for confusion matrix

# Output Configuration
OUTPUT_FORMAT = "space"           # Options: "space", "tab", "comma"
SAVE_REPORTS = True               # Save reports to files?
DETAILED_OUTPUT = True            # Show detailed statistics?

# =============================================================================
# Analysis Execution (Do not modify below this line)
# =============================================================================

print("=" * 70)
print("PYOCCAM ADVANCED ANALYSIS")
print("=" * 70)
print(f"Configuration:")
print(f"  Dataset: {DATASET}")
print(f"  Search Algorithms: {', '.join(SEARCH_TYPES)}")
print(f"  Levels: {SEARCH_LEVELS}, Width: {SEARCH_WIDTH}")
print(f"  Model Selection: {MODEL_SELECTION}")
print(f"  Top Models to Analyze: {ANALYZE_TOP_N}")
print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 70)

# Step 1: Load Data
print("\n[Step 1/6] Loading data...")
print("-" * 40)

if DATASET == "dementia":
    data = pyoccam.load_dementia()
elif DATASET == "landslides":
    data = pyoccam.load_landslides()
elif os.path.exists(DATASET):
    data = pyoccam.load_data(DATASET)
else:
    raise FileNotFoundError(f"Dataset not found: {DATASET}")

print(f"✓ Loaded: {os.path.basename(data.data_file)}")
print(f"  Samples: {data.n_samples}")
print(f"  Features: {data.n_features} independent variables")
print(f"  Target: {data.target_name}")

if DETAILED_OUTPUT:
    print(f"\n  Feature variables:")
    for i, var in enumerate(data.feature_names[:10], 1):
        print(f"    {i:2d}. {var}")
    if len(data.feature_names) > 10:
        print(f"    ... and {len(data.feature_names) - 10} more")

manager = data.manager

# Step 2: Configure Output
print("\n[Step 2/6] Configuring analysis...")
print("-" * 40)

if OUTPUT_FORMAT == "comma":
    manager.set_report_separator(pyoccam.COMMASEP)
elif OUTPUT_FORMAT == "tab":
    manager.set_report_separator(pyoccam.TABSEP)
else:
    manager.set_report_separator(pyoccam.SPACESEP)

manager.set_report_variables("Level$I, h, ddf, dLR, Alpha, %dH(DV), dAIC, dBIC, Inf")

print(f"✓ Configuration complete")

# Step 3: Run Multiple Searches
print(f"\n[Step 3/6] Running {len(SEARCH_TYPES)} search algorithm(s)...")
print("-" * 40)

search_results = {}
for search_type in SEARCH_TYPES:
    print(f"\n  Running {search_type}...")
    report = manager.generate_search_report(search_type, SEARCH_LEVELS, SEARCH_WIDTH)
    search_results[search_type] = report
    
    # Count models
    lines = [l for l in report.strip().split('\n') if l.strip()]
    model_count = len([l for l in lines if l.strip() and l.strip()[0].isdigit()])
    print(f"    ✓ Found {model_count} models")
    
    # Show top 10 models from this search
    print(f"    Top 10 models:")
    in_data_section = False
    lines_shown = 0
    for line in lines:
        if 'ID' in line and 'MODEL' in line:
            in_data_section = True
            print(f"    {line}")
            continue
        if in_data_section and line.strip() and line.strip()[0].isdigit():
            print(f"    {line}")
            lines_shown += 1
            if lines_shown >= 10:
                break

# Step 4: Model Selection
print(f"\n[Step 4/6] Selecting best models by {MODEL_SELECTION}...")
print("-" * 40)

# Get best model by selected criterion
if MODEL_SELECTION.upper() == "BIC":
    best_model = manager.get_best_model_by_bic()
elif MODEL_SELECTION.upper() == "AIC":
    best_model = manager.get_best_model_by_aic()
elif MODEL_SELECTION.upper() == "INFO":
    best_model = manager.get_best_model_by_information()
else:
    raise ValueError(f"Invalid MODEL_SELECTION: {MODEL_SELECTION}")

print(f"✓ Best model by {MODEL_SELECTION}: {best_model}")

# Show best by all criteria if requested
if COMPARE_ALL_CRITERIA:
    print("\n  Best models by each criterion:")
    best_bic = manager.get_best_model_by_bic()
    best_aic = manager.get_best_model_by_aic()
    best_info = manager.get_best_model_by_information()
    print(f"    BIC:         {best_bic}")
    print(f"    AIC:         {best_aic}")
    print(f"    Information: {best_info}")

# Step 5: Fit Top N Models
print(f"\n[Step 5/6] Fitting top {ANALYZE_TOP_N} model(s)...")
print("-" * 40)

fit_results = {}
models_to_fit = [best_model]

# Get additional top models if needed
if ANALYZE_TOP_N > 1:
    # Parse search results to get top models
    for search_type, report in search_results.items():
        lines = [l.strip() for l in report.strip().split('\n') if l.strip() and not l.startswith('--')]
        data_lines = [l for l in lines if l and l[0].isdigit()]
        
        for line in data_lines[:ANALYZE_TOP_N]:
            parts = line.split()
            if len(parts) > 1:
                model_name = parts[1]
                if model_name not in models_to_fit:
                    models_to_fit.append(model_name)
                    if len(models_to_fit) >= ANALYZE_TOP_N:
                        break
        if len(models_to_fit) >= ANALYZE_TOP_N:
            break

# Fit each model
for i, model in enumerate(models_to_fit[:ANALYZE_TOP_N], 1):
    print(f"\n  [{i}/{ANALYZE_TOP_N}] Fitting {model}...")
    fit_report = manager.generate_fit_report(model)
    
    if fit_report:
        fit_results[model] = fit_report
        print(f"      ✓ Success")
        
        # Extract key statistics
        if DETAILED_OUTPUT:
            print(f"\n      Key Statistics:")
            fit_lines = fit_report.split('\n')
            for line in fit_lines[:25]:
                if any(keyword in line for keyword in ['H(', 'ddf', 'LR', 'AIC', 'BIC', 'Alpha', 'Information', 
                                                         'Degrees of freedom', 'Sample Size', 'captured']):
                    print(f"        {line.strip()}")
        
        # Get confusion matrix
        if EXTRACT_CONFUSION_MATRICES and hasattr(manager, 'get_confusion_matrix'):
            cm = manager.get_confusion_matrix(model, TARGET_STATE)
            if cm and isinstance(cm, dict) and "error" not in cm:
                tn = cm.get('tn', 0)
                fp = cm.get('fp', 0)
                fn = cm.get('fn', 0)
                tp = cm.get('tp', 0)
                total = tp + tn + fp + fn
                if total > 0:
                    accuracy = (tp + tn) / total
                    print(f"        Accuracy: {accuracy:.2%} (TP={tp:.0f}, TN={tn:.0f}, FP={fp:.0f}, FN={fn:.0f})")
    else:
        print(f"      ✗ Fit failed")

# Step 6: Model Comparison
if len(fit_results) > 1:
    print(f"\n[Step 6/6] Model comparison...")
    print("-" * 40)
    print("\n  Model Performance Summary:")
    print(f"  {'Model':<20} {'Accuracy':<10}")
    print(f"  {'-'*30}")
    
    for model in fit_results.keys():
        if hasattr(manager, 'get_confusion_matrix'):
            cm = manager.get_confusion_matrix(model, TARGET_STATE)
            if cm and isinstance(cm, dict) and "error" not in cm:
                tn = cm.get('tn', 0)
                fp = cm.get('fp', 0)
                fn = cm.get('fn', 0)
                tp = cm.get('tp', 0)
                total = tp + tn + fp + fn
                if total > 0:
                    accuracy = (tp + tn) / total
                    print(f"  {model:<20} {accuracy:>8.2%}")

# Save Reports
if SAVE_REPORTS:
    print("\n[Saving Reports]")
    print("-" * 40)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    saved_files = []
    
    # Save search reports
    for search_type, report in search_results.items():
        filename = f"search_{search_type}_{timestamp}.txt"
        with open(filename, 'w') as f:
            f.write(report)
        saved_files.append(filename)
        print(f"✓ Search report: {filename}")
    
    # Save fit reports
    for model, report in fit_results.items():
        filename = f"fit_{model.replace(':', '_')}_{timestamp}.txt"
        with open(filename, 'w') as f:
            f.write(report)
        saved_files.append(filename)
        print(f"✓ Fit report: {filename}")
    
    # Save summary
    summary_filename = f"analysis_summary_{timestamp}.txt"
    with open(summary_filename, 'w') as f:
        f.write("OCCAM Advanced Analysis Summary\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Dataset: {os.path.basename(data.data_file)}\n")
        f.write(f"Sample Size: {data.n_samples}\n")
        f.write(f"Features: {data.n_features}\n")
        f.write(f"Target: {data.target_name}\n\n")
        f.write(f"Search Algorithms: {', '.join(SEARCH_TYPES)}\n")
        f.write(f"Search Depth: {SEARCH_LEVELS} levels\n")
        f.write(f"Search Width: {SEARCH_WIDTH} models per level\n\n")
        f.write(f"Best Model ({MODEL_SELECTION}): {best_model}\n\n")
        f.write(f"Models Analyzed: {len(fit_results)}\n")
        for model in fit_results.keys():
            f.write(f"  - {model}\n")
        f.write(f"\nGenerated Files:\n")
        for filename in saved_files:
            f.write(f"  - {filename}\n")
    
    saved_files.append(summary_filename)
    print(f"✓ Summary: {summary_filename}")

# Final Summary
print("\n" + "=" * 70)
print("ADVANCED ANALYSIS COMPLETE")
print("=" * 70)
print(f"Dataset: {os.path.basename(data.data_file)}")
print(f"Best Model ({MODEL_SELECTION}): {best_model}")
print(f"Algorithms Tested: {len(SEARCH_TYPES)}")
print(f"Models Analyzed: {len(fit_results)}")
if SAVE_REPORTS:
    print(f"\n{len(saved_files)} report files saved to current directory")
print("=" * 70)
